/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Module.h
 * Author: Sammy Guergachi <sguergachi at gmail.com>
 *
 * Created on 1 de marzo de 2019, 12:38
 */

#ifndef MODULE_H
#define MODULE_H
#include "Theme.h"
#include "Date.h"
#include "Garito.h"



    
    
     void ShowTemazo ( Theme temazo);
    
     void ShowGarito ( Garito g1 );
     
     void  ShowFecha ( Date f1 );
     
     void DataGarito (  Garito &g1 );
    
    
    


#endif /* MODULE_H */

